# Traitement-statistique-avec-R
Ce dépôt contient l'ensemble des ressources pédagogique en lien avec le cours de "Traitement statistique avec R".
